# Support

The issue queue we have here on GitHub is primarily intended for tracking features,
bugs and work items associated with this Datadog open source project.

For any other support request, please reach out through one of the following:

 * Contact our [support](https://docs.datadoghq.com/help/)
 * Join us [on Slack](http://datadoghq.slack.com)
