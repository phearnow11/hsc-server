# coding=utf-8
"""Test scenarios."""

from pytest_bdd import scenarios

scenarios("../../tests/scenarios/features/v1", "../../tests/scenarios/features/v2")
