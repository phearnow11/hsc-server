#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/MurmurHash2.hpp"
#endif
