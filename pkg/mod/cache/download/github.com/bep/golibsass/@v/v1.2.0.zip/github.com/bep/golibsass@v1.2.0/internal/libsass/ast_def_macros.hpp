#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/ast_def_macros.hpp"
#endif
